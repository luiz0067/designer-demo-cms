class NoticiaVideo < ApplicationRecord
  belongs_to :Noticia
end
