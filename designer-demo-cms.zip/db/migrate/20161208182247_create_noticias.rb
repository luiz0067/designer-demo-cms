class CreateNoticias < ActiveRecord::Migration[5.0]
  def change
    create_table :noticias do |t|
      t.string :titulo
      t.string :subtitulo
      t.string :fonte
      t.text :descricao
      t.boolean :ocultar

      t.timestamps
    end
  end
end
