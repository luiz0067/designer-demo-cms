class W2uiController < ActionController::Base
	def index
	end
	def file_assets
		if 	not params[:model].nil?
			if params[:id].nil?
				file_assets = request.fullpath[params[:model].length+1,request.fullpath.length] 					
			else
				file_assets = request.fullpath[params[:model].length+params[:id].length+2,request.fullpath.length] 
			end
			send_file './public'+file_assets, type: MIME::Types.type_for('./public'+file_assets).first.content_type, disposition: 'inline'
		end
	end
end
#redirect_to file_assets
#File.open('./public'+file_assets,'r') do |fileb|
#   while line = fileb.gets
# 		puts line
#    end
#end