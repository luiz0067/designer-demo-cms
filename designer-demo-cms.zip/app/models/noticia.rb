class Noticia < ApplicationRecord
end
