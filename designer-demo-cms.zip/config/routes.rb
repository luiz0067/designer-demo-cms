Rails.application.routes.draw do
  resources :noticias


  get  '/:model/img/*pages'              => 'w2ui#file_assets'
  get  '/:model/libs/*pages'             => 'w2ui#file_assets'
  get  '/:model/upload/ckeditor/*pages'  => 'w2ui#file_assets'
  get  '/:model/:id/app/*pages'          => 'w2ui#file_assets'

  post '/:model/img/*pages'              => 'w2ui#file_assets'
  post '/:model/libs/*pages'             => 'w2ui#file_assets'
  post '/:model/upload/ckeditor/*pages'  => 'w2ui#file_assets'
  post '/:model/:id/app/*pages'          => 'w2ui#file_assets'

  get  'w2ui/index'                      => 'w2ui#index'
  post 'w2ui/index'                      => 'w2ui#index'

  get  '/:model/w2ui/index'              => 'w2ui#index'
  post '/:model/w2ui/index'              => 'w2ui#index'

  get  '/:model/:id/w2ui/index'          => 'w2ui#index'
  post '/:model/:id/w2ui/index'          => 'w2ui#index'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
